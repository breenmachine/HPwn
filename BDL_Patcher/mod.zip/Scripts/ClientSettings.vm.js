
    function ChangeVisibility(sender, target)
    {
    document.getElementById(target).disabled = !document.getElementById(sender).checked;
    }

    function SetValueOnSubmit()
    {
    document.getElementById('SslEnabled').value = document.getElementById('SslEnabledCB').checked;
    document.getElementById('LoggingEnabled').value = document.getElementById('LoggingEnabledCB').checked;
    }

    function htmlDecode(input){
    var e = document.createElement('div');
    e.innerHTML = input;
    return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
    }